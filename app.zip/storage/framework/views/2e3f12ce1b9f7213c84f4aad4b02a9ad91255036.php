<!doctype html>
<html lang="en" class="no-js">
<head>
    <title><?php echo e(ucwords(str_replace('_', ' ', Route::currentRouteName()))); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,600,700,300' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>" media="screen">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/font-awesome.css')); ?>" media="screen">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/email.css')); ?>" media="screen">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/layout2.css')); ?>" media="screen">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/media.css')); ?>" media="all"/>
    <link href="<?php echo e(url('public/css/screen.css')); ?>" type="text/css" rel="stylesheet">
</head>
<body>
<header>
    <div class="headerMiddle clearfix">
        <div class="container">
            <section class="row">
                <a href="<?php echo e(url('')); ?>" class="logoBlock"><img src="<?php echo e(url('public/images/logo.png')); ?>" alt=""/></a>
            </section>
        </div>
    </div>
</header>

<div class="col-md-12">
    <h3 class="email_title">Welcome , <?php echo e($name); ?></h3>
</div>
<div class="col-md-12">
    <p class="email_body">Thank you for signing up in weekenddocs.com . Please verify your email to continue with us .</p>
</div>
<?php if($password != null): ?>
<div class="col-md-6">
    <p class="email_body">Your Password is :<?php echo e($password); ?></p>
</div>
<?php endif; ?>
<div class="col-md-12">
    <form action="<?php echo e(url('/confirmation/'.$user_id.'/'.$confirmation_code)); ?>" method="get">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">
        <input type="hidden" name="confirmation_code" value="<?php echo e($confirmation_code); ?>">
        <input type="hidden" name="user_level" value="<?php echo e($user_level); ?>">
        <input type="submit" value="Verify Me">
    </form>
</div>

<footer class="footerSec clearfix">
    <p class="copyRight" style="text-align: center;">Copyright © weekenddocs.com <?php echo e(date('Y')); ?></p>
</footer>
<script type="text/javascript" src="<?php echo e(url('public/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('public/js/bootstrap.min.js')); ?>"></script>
</body>
</html>