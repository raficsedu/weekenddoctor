@extends('layouts.master')

@section('content')
<section class="bodySec joinUsBody clearfix" style="background:none; padding:20px;">
    <div class="container">
        <section class="row">
            <h1>Authorization</h1>
            <div class="line1"></div>

            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12" style="padding:20px;">
                        <p style="padding:3px; line-height:20px; font-size:15px; color:#575757;"> <!-- tabs left -->
                            <strong style="color:#298DC6; font-size:24px; font-weight:normal;"> Lorem Ipsum is simply dummy text of the printing and typesetting </strong>
                            <br><br>
                            industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, <br><br>
                            but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                        <p style="padding:3px; line-height:20px; font-size:15px; color:#575757;">
                            <br><br>
                            <strong  style="color:#298DC6; font-size:24px; font-weight:normal;">It is a long established fact that a reader will be distracted by the</strong>
                            <br><br>
                            readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
                        </p>
                        <br><br>
                        <p style="padding:3px; line-height:20px; font-size:15px; color:#575757;">
                            <strong  style="color:#298DC6; font-size:24px; font-weight:normal;"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. </strong>
                            <br><br>
                            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,
                            <br><br>
                            but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            <br>
                        <p style="padding:3px; line-height:20px; font-size:15px; color:#575757;">
                            <br><br>
                            <strong  style="color:#298DC6; font-size:24px; font-weight:normal;">It is a long established fact that a reader will be distracted by the</strong>
                            <br><br>
                            readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
                        </p>


                        <!-- /tabs -->
                    </div>
                </div>
                <!-- /row -->
            </div>
            <hr>
        </section>
    </div>
</section>
@endsection